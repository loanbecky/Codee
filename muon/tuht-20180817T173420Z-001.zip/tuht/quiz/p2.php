<!DOCTYPE html>
<html>
<head>
	<title>quiz app</title>
	<h1 style="text-align: center; font-family: sans-serif; color: #5c00e6; text-transform: uppercase;"> questions page 2</h1>
</head>
<style type="text/css">
	.quiz{
		width: 750px;
		height: auto;
		background-color: lightblue;
		border-radius: 15px;
		padding: 25px;
		margin-left:250px;
		margin-top: 25px;

	}
	.answer{
		background-color: #ccfff5;
		margin-top: 5px;
		margin-bottom: 5px;
		margin-left: 15px;
        width: 90%;
        border-radius: 15px; 

	}
	.ques li {
		padding: 5px;
		font-weight: bold;
		margin-top: 5px;
	}
	.nextpage{
		background-color: red;
		border: solid white 2px;
		padding: 7px;
		margin-left:650px;
	}
	.nextpage a{
	    color: white;
	    text-transform: uppercase;
	    text-decoration: none;
	}
	.prepage{
		background-color: red;
		border: solid white 2px;
		padding: 7px;
		margin-left:650px; 
	}
	.prepage a{
	    color: white;
	    text-transform: uppercase;
	    text-decoration: none;
	}
</style> 
<body>
	<ol type="1" class="ques">
		<form class="quiz" method="post">
		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon"checked>milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>
	
		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<ol type="A" class="answer">
		<li><input type="radio" name="chon">milk</li>
		<li><input type="radio" name="chon">tea</li>
		<li><input type="radio" name="chon">bread</li>
		<li><input type="radio" name="chon">wine</li>
		</ol>

		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<select name="ques11">
		<ol type="A" class="answer">
		<li><option>milk</option></li>
		<li><option>milk</option></li>
		<li><option>tea</option></li>
		</ol>
		</select>
		<li>Question : what do I want to eat now? <br></li>
		Your answer : <br>
		<select name="ques12">
		<ol type="A" class="answer">
		<li><option>milk</option></li>
		<li><option>milk</option></li>
		<li><option>tea</option></li>
		</ol>
		</select>
	</form>
	</ol>
	<button class="nextpage"><a href="p3.php">next page</a></button>
	<button class="prepage"><a href="ex3w2.php">prev page</a></button>
</body>
</html>