<!DOCTYPE html>
<html>
<head>
	<title>quiz app</title>
	<h1 style="text-align: center"> quiz questions</h1>
</head>
<body>
	<form method="post">
		Question 1 : what do I want to eat now? <br>
		Your answer : <br>
		<ol>
			<button><li> milk </li></button><br>
			<button><li> tea </li></button><br>
			<button><li> coffee </li></button><br>
		</ol> <br>
		<input type="submit" name="answer" value="OK"></input>
	</form>
			
	<form method="post">
		Question 2 : How can I be good at programming? <br>
		Your answer : <br>
		<ol>
			<button><li> Practise </li></button><br>
			<button><li> Ask Mr Cong </li></button><br>
			<button><li> I dont know </li></button><br>
		</ol> <br>
		<input type="submit" name="answer" value="OK"></input>
	</form>
	<form method="post">
		Question 3 : How can I make more money ? <br>
		Your answer : <br>
		<ol>
			<button><li> Ask Google </li></button><br>
			<button><li> Ask Duong co nuong </li></button><br>
			<button><li> In thefuture you will know </li></button><br>
		</ol> <br>
		<input type="submit" name="answer" value="OK"></input>
	</form>

</body>
</html>